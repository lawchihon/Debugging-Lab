## Debugging Game for iOS Lab

![Imgur](http://i.imgur.com/oQbQLf9.png)
